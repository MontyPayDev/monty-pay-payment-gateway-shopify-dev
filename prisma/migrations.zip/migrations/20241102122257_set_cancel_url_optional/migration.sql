-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE `new_PaymentSession` (
    `id` TEXT NOT NULL PRIMARY KEY,
    `gid` TEXT NOT NULL,
    `group` TEXT NOT NULL,
    `amount` DECIMAL NOT NULL,
    `test` BOOLEAN NOT NULL,
    `currency` TEXT NOT NULL,
    `kind` TEXT NOT NULL,
    `shop` TEXT NOT NULL,
    `paymentMethod` TEXT NOT NULL,
    `customer` TEXT NOT NULL,
    `cancelUrl` TEXT,
    `proposedAt` DATETIME NOT NULL,
    `status` TEXT
);
INSERT INTO `new_PaymentSession` (`amount`, `cancelUrl`, `currency`, `customer`, `gid`, `group`, `id`, `kind`, `paymentMethod`, `proposedAt`, `shop`, `status`, `test`) SELECT `amount`, `cancelUrl`, `currency`, `customer`, `gid`, `group`, `id`, `kind`, `paymentMethod`, `proposedAt`, `shop`, `status`, `test` FROM `PaymentSession`;
DROP TABLE `PaymentSession`;
ALTER TABLE `new_PaymentSession` RENAME TO `PaymentSession`;
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
