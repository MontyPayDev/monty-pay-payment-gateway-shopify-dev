-- AlterTable
ALTER TABLE `Configuration` MODIFY `accountName` VARCHAR(191) NULL;
