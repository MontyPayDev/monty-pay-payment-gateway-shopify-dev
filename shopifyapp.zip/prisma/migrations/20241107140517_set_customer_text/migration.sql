-- AlterTable
ALTER TABLE `PaymentSession` MODIFY `customer` TEXT NOT NULL;
