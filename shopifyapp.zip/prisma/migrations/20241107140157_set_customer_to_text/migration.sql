-- AlterTable
ALTER TABLE `PaymentSession` MODIFY `customer` VARCHAR(191) NOT NULL;
